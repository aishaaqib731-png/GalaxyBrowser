const { app, BrowserWindow, WebContentsView, ipcMain, session, shell, dialog } = require("electron");
const path = require("node:path");
const fs = require("node:fs");
const { ElectronBlocker } = require("@ghostery/adblocker-electron");

let win;
let blocker;
const tabs = new Map();
let activeTabId = null;
let nextTabId = 1;
const TOOLBAR_HEIGHT = 122;

function safeUrl(input) {
  const value = String(input || "").trim();
  if (!value) return "https://search.brave.com";
  if (/^(javascript|data|file|vbscript):/i.test(value)) throw new Error("This URL scheme is blocked.");
  if (/^https?:\/\//i.test(value)) return value;
  if (/^[\w.-]+\.[a-z]{2,}([/:?#].*)?$/i.test(value) && !/\s/.test(value)) return `https://${value}`;
  return `https://search.brave.com/search?q=${encodeURIComponent(value)}`;
}

function sendState() {
  if (!win || win.isDestroyed()) return;
  win.webContents.send("tabs:state", {
    tabs: [...tabs.values()].map(t => ({ id: t.id, title: t.title, url: t.url, loading: t.loading })),
    activeTabId
  });
}

function layoutViews() {
  if (!win || win.isDestroyed()) return;
  const [width, height] = win.getContentSize();
  for (const tab of tabs.values()) {
    tab.view.setBounds({
      x: 0,
      y: TOOLBAR_HEIGHT,
      width: Math.max(0, width),
      height: Math.max(0, height - TOOLBAR_HEIGHT)
    });
    tab.view.setVisible(tab.id === activeTabId && !tab.isHome && height > TOOLBAR_HEIGHT);
  }
}

async function createTab(url = "") {
  const id = String(nextTabId++);
  const ses = session.fromPartition("persist:galaxy");
  const view = new WebContentsView({
    webPreferences: {
      session: ses,
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webviewTag: false
    }
  });
  const tab = { id, view, title: "New tab", url: "", loading: false, isHome: !url, history: [], historyIndex: -1 };
  tabs.set(id, tab);
  win.contentView.addChildView(view);
  view.setBackgroundColor("#0c0f16");

  view.webContents.setWindowOpenHandler(({ url: target }) => {
    createTab(target);
    return { action: "deny" };
  });
  view.webContents.on("will-navigate", (event, target) => {
    if (!/^https?:/i.test(target)) event.preventDefault();
  });
  view.webContents.on("page-title-updated", (_event, title) => {
    tab.title = title || tab.url || "Galaxy";
    sendState();
  });
  view.webContents.on("did-start-loading", () => { tab.loading = true; sendState(); });
  view.webContents.on("did-stop-loading", () => { tab.loading = false; sendState(); });
  view.webContents.on("did-navigate", (_event, target) => {
    tab.url = target;
    tab.history = tab.history.slice(0, tab.historyIndex + 1);
    tab.history.push(target);
    tab.historyIndex = tab.history.length - 1;
    sendState();
  });
  view.webContents.on("render-process-gone", () => {
    tab.title = "Page crashed";
    sendState();
  });
  activeTabId = id;
  layoutViews();
  if (url) {
    tab.isHome = false;
    try { await view.webContents.loadURL(safeUrl(url)); }
    catch (e) { tab.title = "Could not load page"; tab.url = ""; tab.isHome = true; layoutViews(); sendState(); }
  }
  sendState();
  return id;
}

function activeTab() { return tabs.get(activeTabId); }
function activateTab(id) {
  if (!tabs.has(String(id))) return;
  activeTabId = String(id);
  layoutViews();
  sendState();
}
function closeTab(id) {
  id = String(id);
  const tab = tabs.get(id);
  if (!tab) return;
  win.contentView.removeChildView(tab.view);
  tab.view.webContents.close();
  tabs.delete(id);
  if (activeTabId === id) activeTabId = [...tabs.keys()].at(-1) || null;
  if (!activeTabId) createTab();
  else { layoutViews(); sendState(); }
}
function navigate(input) {
  const tab = activeTab();
  if (!tab) return;
  let url;
  try { url = safeUrl(input); } catch (e) { win.webContents.send("app:toast", e.message); return; }
  tab.url = url;
  tab.isHome = false;
  layoutViews();
  tab.view.webContents.loadURL(url).catch(() => win.webContents.send("app:toast", "This page could not be loaded."));
  sendState();
}

async function createWindow() {
  win = new BrowserWindow({
    width: 1440, height: 900, minWidth: 720, minHeight: 520,
    backgroundColor: "#0c0f16",
    title: "Galaxy Browser",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  await win.loadFile(path.join(__dirname, "index.html"));
  win.on("resize", layoutViews);
  win.on("closed", () => { win = null; });
  await createTab();
  layoutViews();
}

app.whenReady().then(async () => {
  try {
    blocker = await ElectronBlocker.fromPrebuiltAdsAndTracking(fetch);
    blocker.enableBlockingInSession(session.fromPartition("persist:galaxy"));
    console.log("Galaxy ad/tracker filter enabled.");
  } catch (err) {
    console.warn("Ad-block filter unavailable; browser will run without it:", err.message);
  }
  await createWindow();
  app.on("activate", () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on("window-all-closed", () => { if (process.platform !== "darwin") app.quit(); });

ipcMain.handle("tabs:new", (_e, url) => createTab(url || ""));
ipcMain.handle("tabs:activate", (_e, id) => activateTab(id));
ipcMain.handle("tabs:close", (_e, id) => closeTab(id));
ipcMain.handle("browser:navigate", (_e, url) => navigate(url));
ipcMain.handle("browser:back", () => { const t = activeTab(); if (t?.view.webContents.canGoBack()) t.view.webContents.goBack(); });
ipcMain.handle("browser:forward", () => { const t = activeTab(); if (t?.view.webContents.canGoForward()) t.view.webContents.goForward(); });
ipcMain.handle("browser:reload", () => activeTab()?.view.webContents.reload());
ipcMain.handle("browser:home", () => { const t = activeTab(); if (t) { t.isHome = true; t.url = ""; t.title = "New tab"; t.loading = false; layoutViews(); sendState(); } });
ipcMain.handle("browser:external", async (_e, url) => { if (url && /^https?:/i.test(url)) await shell.openExternal(url); });
ipcMain.handle("browser:find", (_e, text) => activeTab()?.view.webContents.findInPage(String(text || "")));
ipcMain.handle("browser:stopFind", () => activeTab()?.view.webContents.stopFindInPage("clearSelection"));
ipcMain.handle("browser:zoom", (_e, delta) => {
  const wc = activeTab()?.view.webContents;
  if (wc) wc.setZoomFactor(Math.min(2, Math.max(0.5, wc.getZoomFactor() + Number(delta || 0))));
});
ipcMain.handle("browser:print", () => activeTab()?.view.webContents.print());
ipcMain.handle("app:version", () => app.getVersion());
ipcMain.handle("app:export-bookmarks", async (_e, data) => {
  const result = await dialog.showSaveDialog(win, { defaultPath: "galaxy-bookmarks.json", filters: [{ name: "JSON", extensions: ["json"] }] });
  if (!result.canceled && result.filePath) fs.writeFileSync(result.filePath, JSON.stringify(data, null, 2), "utf8");
});
