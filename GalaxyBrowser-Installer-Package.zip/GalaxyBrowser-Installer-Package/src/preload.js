const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("galaxy", {
  newTab: url => ipcRenderer.invoke("tabs:new", url),
  activateTab: id => ipcRenderer.invoke("tabs:activate", id),
  closeTab: id => ipcRenderer.invoke("tabs:close", id),
  navigate: url => ipcRenderer.invoke("browser:navigate", url),
  back: () => ipcRenderer.invoke("browser:back"),
  forward: () => ipcRenderer.invoke("browser:forward"),
  reload: () => ipcRenderer.invoke("browser:reload"),
  home: () => ipcRenderer.invoke("browser:home"),
  openExternal: url => ipcRenderer.invoke("browser:external", url),
  find: text => ipcRenderer.invoke("browser:find", text),
  stopFind: () => ipcRenderer.invoke("browser:stopFind"),
  zoom: delta => ipcRenderer.invoke("browser:zoom", delta),
  print: () => ipcRenderer.invoke("browser:print"),
  version: () => ipcRenderer.invoke("app:version"),
  exportBookmarks: data => ipcRenderer.invoke("app:export-bookmarks", data),
  onTabsState: cb => ipcRenderer.on("tabs:state", (_event, state) => cb(state)),
  onToast: cb => ipcRenderer.on("app:toast", (_event, message) => cb(message))
});
