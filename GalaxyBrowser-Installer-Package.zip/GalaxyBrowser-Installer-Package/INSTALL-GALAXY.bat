@echo off
setlocal
cd /d "%~dp0"
title Galaxy Browser Setup
color 5F
echo ========================================
echo        GALAXY BROWSER SETUP
echo ========================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 20 or newer is required for this source-based setup.
  echo Opening the official Node.js download page...
  start "" "https://nodejs.org/en/download"
  echo Install Node.js, then run this setup again.
  pause
  exit /b 1
)
echo Installing app dependencies. This requires internet access...
call npm install
if errorlevel 1 (
  echo Installation failed. Check internet access and try again.
  pause
  exit /b 1
)
set "APPDIR=%~dp0"
set "SHORTCUT=%USERPROFILE%\Desktop\Galaxy Browser.lnk"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$w=New-Object -ComObject WScript.Shell; $s=$w.CreateShortcut('%SHORTCUT%'); $s.TargetPath='%APPDIR%RUN-GALAXY-WINDOWS.bat'; $s.WorkingDirectory='%APPDIR%'; $s.Description='Launch Galaxy Browser'; $s.Save()"
echo.
echo Setup finished. A Galaxy Browser shortcut was added to your desktop.
echo Launching Galaxy Browser now...
call npm start
pause
