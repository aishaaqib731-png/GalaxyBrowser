@echo off
setlocal
cd /d "%~dp0"
echo ========================================
echo          GALAXY BROWSER
 echo ========================================
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed.
  echo Install Node.js 20 or newer from https://nodejs.org/ then run this file again.
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing Galaxy Browser dependencies. This needs internet on first run...
  call npm install
  if errorlevel 1 (
    echo Dependency installation failed. Check your internet connection and try again.
    pause
    exit /b 1
  )
)
echo Starting Galaxy Browser...
call npm start
if errorlevel 1 (
  echo Galaxy Browser closed with an error. Read the messages above for details.
  pause
)
endlocal
