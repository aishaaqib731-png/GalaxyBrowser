# Galaxy Browser 2.0 — Chromium-based starter

Galaxy Browser is an Electron desktop browser starter. Electron embeds Chromium and Node.js. This project uses separate Chromium `WebContentsView` instances for actual pages, a hardened preload bridge, an address/search bar, tabs, bookmarks, local history, theme toggle, voice search (when supported), find-on-page, zoom, print, and an optional ad/tracker filter list.

## Honest feature status

### Implemented in this starter
- Desktop app built on Electron/Chromium for Windows, macOS, and Linux.
- Multiple tabs backed by separate Chromium web contents.
- Address bar with configurable Google / Brave Search / DuckDuckGo / Bing query fallback.
- Updated Galaxy home UI with sidebar navigation, quick-access shortcuts, feature cards, recommendation links, and settings panel.
- Keyboard shortcuts: Ctrl/Cmd+L, T, W, R, F.
- Back, forward, reload, home, external-open action.
- Local bookmarks/history/shortcuts/theme storage.
- Bookmark export to JSON.
- Ad/tracker blocking integration via `@ghostery/adblocker-electron`; it attempts to load the package's prebuilt filter data at startup. If loading fails, the app logs a warning and continues without blocking.
- Voice search when the Electron renderer's browser environment supports Web Speech API and microphone permission.
- UI panels for downloads and extensions that clearly explain which manager/store workflows are not yet implemented.
- Find in page, zoom, print, and dark/light interface.
- Basic Electron hardening: context isolation, no Node integration in renderer/pages, sandbox, restricted URL schemes, external windows routed to tabs.

### Not included / not Brave parity
- This is a source starter, not a signed installer. Build it on each target OS.
- It does not include Brave Rewards, Brave Wallet, Tor private windows, Sync, fingerprinting defenses comparable to Brave, Shields' full rules/UI, built-in VPN, password manager, extension store, or Brave's proprietary services.
- Incognito/private windows, cookie-per-site controls, download manager UI, import from other browsers, sync, automatic updates, parental controls, and mobile-native builds are not implemented.
- Ad-block filter coverage depends on package/filter-list availability and is not guaranteed to match Brave. Test sites you rely on.
- Browser security updates are your responsibility: update Electron regularly and rebuild releases.
- All-platform means the desktop source can be packaged separately for Windows/macOS/Linux. Android/iOS require separate native integration and testing; this Electron project is not an Android/iOS app and cannot be turned into one by renaming the file.

## Requirements
- Node.js 20+ (recommended current LTS) and npm.
- Internet access for installing packages and filter data.
- For platform-specific packaging, build on the target OS where possible.

## Run in development
1. Extract the ZIP.
2. Open a terminal in the extracted `GalaxyBrowser-Advanced` folder.
3. Run:
   ```bash
   npm install
   npm start
   ```
4. If the filter package cannot load its list, the app still opens; check the terminal log.

## Build installers
Run on the operating system you want to package:
```bash
npm run dist:win
npm run dist:mac
npm run dist:linux
```
Output goes to `release/`. Cross-platform packaging can require native toolchains and signing credentials; macOS signing/notarization requires Apple developer setup.

## API keys / AI
No API key is required for core browsing. This starter does not call an AI service. If you add an AI assistant, keep provider keys in a backend you control; do not ship private API keys inside renderer JavaScript or a public app bundle.

## Safety notes before public release
- Audit and pin dependencies, add automated tests, set a Content Security Policy, handle downloads and permissions deliberately, add a clear privacy policy, and review all Electron security recommendations.
- Implement permission prompts for camera/microphone/location before enabling those capabilities.
- Add a safe download manager and malicious-download handling.
- Review ad-blocker package APIs and filter-list licensing/availability before distributing.
- Never claim complete ad blocking, anonymity, or Brave-level privacy without independent security testing.
