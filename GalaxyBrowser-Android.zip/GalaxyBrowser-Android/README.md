# Galaxy Browser for Android (starter project)

This is a native Android WebView browser starter with a dark Galaxy-themed home screen, URL/search bar, back/forward/home/reload, bookmarks, basic history storage, and common site shortcuts. It is not a Chromium fork and does not yet include full tab management, an extension store, built-in VPN, cross-device sync, or Brave's full privacy protections.

## Easiest build path using only an Android phone/tablet

This project includes a GitHub Actions workflow to build a debug APK in the cloud, so you don't need a PC with Android Studio. You will need a GitHub account and a browser on your phone.

1. Download and extract `GalaxyBrowser-Android.zip`.
2. In GitHub, create a new repository named `GalaxyBrowser`.
3. Upload the *contents* of this folder to the repository root (not the enclosing folder itself). Make sure `.github/workflows/build-apk.yml` is included. GitHub's website may offer **Add file → Upload files**; upload files in batches if needed. For easier mobile upload, use GitHub's web interface in desktop mode if available.
4. Open the repository's **Actions** tab. Choose **Build Galaxy Browser APK** and tap **Run workflow** (or push to `main` to trigger it).
5. Wait for the workflow to finish successfully. Open the completed run and download the `GalaxyBrowser-debug-apk` artifact. GitHub downloads it as a ZIP; extract that ZIP to get `app-debug.apk`.
6. Tap `app-debug.apk` in your Downloads app. If Android asks, allow your browser or file manager to **Install unknown apps**, then install it. Only install APKs you built or trust.

## Build on a computer

Install Android Studio and JDK 17, open this project, let Gradle sync, then build the debug APK with `gradle assembleDebug` or Android Studio's Build APK command.

## Limitations

This is a starter app for testing, not a production-hardened browser. It uses Android System WebView, not a bundled Chromium engine. Avoid entering sensitive information until the app has been reviewed and hardened. The debug APK is unsigned for release distribution and is intended for personal testing.
