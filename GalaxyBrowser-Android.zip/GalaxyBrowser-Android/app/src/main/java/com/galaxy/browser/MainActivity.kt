package com.galaxy.browser

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.content.Intent
import android.net.Uri

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 11, 18)
    private val panel = Color.rgb(25, 25, 39)
    private val purple = Color.rgb(167, 139, 250)
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var progress: ProgressBar
    private lateinit var home: LinearLayout
    private val prefs by lazy { getSharedPreferences("galaxy", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        showHome()
    }

    private fun rounded(color: Int, radius: Float = 24f): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = radius
    }

    private fun textButton(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label; textSize = 14f; setTextColor(Color.WHITE); isAllCaps = false
        background = rounded(panel, 20f); setOnClickListener { onClick() }
        minWidth = 0; minimumWidth = 0; setPadding(10, 4, 10, 4)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(12, 8, 12, 6) }
        val brand = TextView(this).apply { text = "✦  GALAXY BROWSER"; textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); setPadding(4, 8, 4, 12) }
        root.addView(brand)
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        address = EditText(this).apply {
            hint = "Search or enter website"; singleLine = true; textSize = 15f; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY)
            setPadding(14, 2, 10, 2); background = rounded(panel, 28f); imeOptions = EditorInfo.IME_ACTION_GO
            setSelectAllOnFocus(true)
            setOnEditorActionListener { _, action, event ->
                if (action == EditorInfo.IME_ACTION_GO || event?.keyCode == KeyEvent.KEYCODE_ENTER) { navigate(address.text.toString()); true } else false
            }
        }
        bar.addView(address, LinearLayout.LayoutParams(0, 50, 1f))
        val go = textButton("Go") { navigate(address.text.toString()) }
        val goLp = LinearLayout.LayoutParams(56, 50); goLp.leftMargin = 6; bar.addView(go, goLp)
        root.addView(bar)
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; progressTintList = android.content.res.ColorStateList.valueOf(purple); visibility = View.GONE }
        root.addView(progress, LinearLayout.LayoutParams(-1, 3))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 7, 0, 7) }
        listOf("‹" to { if (::web.isInitialized && web.canGoBack()) web.goBack() else showHome() },
            "›" to { if (::web.isInitialized && web.canGoForward()) web.goForward() },
            "⌂" to { showHome() },
            "☆" to { saveBookmark() },
            "↻" to { if (::web.isInitialized) web.reload() }).forEach { (label, action) ->
            val b = textButton(label, action); b.textSize = 21f
            val lp = LinearLayout.LayoutParams(0, 44, 1f); lp.setMargins(3, 0, 3, 0); nav.addView(b, lp)
        }
        root.addView(nav)
        home = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(14, 30, 14, 10) }
        web = WebView(this).apply {
            setBackgroundColor(bg); settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.loadsImagesAutomatically = true; settings.javaScriptCanOpenWindowsAutomatically = false
            settings.allowFileAccess = false; settings.allowContentAccess = false
            settings.safeBrowsingEnabled = true
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.scheme == "http" || uri.scheme == "https") return false
                    return try { startActivity(Intent(Intent.ACTION_VIEW, uri)); true } catch (_: Exception) { true }
                }
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) { progress.visibility = View.VISIBLE; if (url != null) address.setText(url) }
                override fun onPageFinished(view: WebView?, url: String?) { progress.visibility = View.GONE; url?.let { address.setText(it); addHistory(it) } }
            }
            webChromeClient = object : WebChromeClient() { override fun onProgressChanged(view: WebView?, newProgress: Int) { progress.progress = newProgress; progress.visibility = if (newProgress >= 100) View.GONE else View.VISIBLE } }
        }
        root.addView(home, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showHome() {
        if (!::home.isInitialized) return
        home.visibility = View.VISIBLE; web.visibility = View.GONE; home.removeAllViews()
        val logo = TextView(this).apply { text = "✦"; textSize = 54f; setTextColor(purple); gravity = Gravity.CENTER }
        home.addView(logo)
        val title = TextView(this).apply { text = "Explore the universe."; textSize = 26f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE); gravity = Gravity.CENTER; setPadding(0, 4, 0, 8) }
        home.addView(title)
        val subtitle = TextView(this).apply { text = "Search privately. Browse freely."; textSize = 15f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER; setPadding(0, 0, 0, 26) }
        home.addView(subtitle)
        val shortcuts = listOf("Google" to "https://www.google.com", "YouTube" to "https://m.youtube.com", "Wikipedia" to "https://www.wikipedia.org", "Brave Search" to "https://search.brave.com", "ChatGPT" to "https://chatgpt.com", "Bookmarks" to "bookmarks")
        shortcuts.forEach { (name, url) ->
            val b = textButton("✦   $name") { if (url == "bookmarks") showBookmarks() else navigate(url) }
            val lp = LinearLayout.LayoutParams(-1, 48); lp.setMargins(0, 5, 0, 5); home.addView(b, lp)
        }
        val note = TextView(this).apply { text = "Galaxy Browser · Android preview"; textSize = 12f; setTextColor(Color.GRAY); gravity = Gravity.CENTER; setPadding(0, 20, 0, 0) }
        home.addView(note)
    }

    private fun navigate(raw: String) {
        var input = raw.trim(); if (input.isEmpty()) return
        if (!input.contains(" ") && input.contains(".") && !input.contains("://")) input = "https://$input"
        else if (!input.startsWith("http://") && !input.startsWith("https://")) input = "https://www.google.com/search?q=" + Uri.encode(input)
        val uri = try { Uri.parse(input) } catch (_: Exception) { null }
        if (uri == null || (uri.scheme != "http" && uri.scheme != "https")) { Toast.makeText(this, "Enter a valid web address", Toast.LENGTH_SHORT).show(); return }
        home.visibility = View.GONE; web.visibility = View.VISIBLE; web.loadUrl(input)
    }

    private fun saveBookmark() {
        if (!::web.isInitialized || web.url.isNullOrBlank()) { Toast.makeText(this, "Open a page first", Toast.LENGTH_SHORT).show(); return }
        val set = prefs.getStringSet("bookmarks", emptySet())?.toMutableSet() ?: mutableSetOf()
        set.add(web.url!!); prefs.edit().putStringSet("bookmarks", set).apply()
        Toast.makeText(this, "Bookmark saved", Toast.LENGTH_SHORT).show()
    }
    private fun addHistory(url: String) {
        val list = prefs.getStringSet("history", emptySet())?.toMutableSet() ?: mutableSetOf()
        list.add(url); prefs.edit().putStringSet("history", list).apply()
    }
    private fun showBookmarks() {
        val items = prefs.getStringSet("bookmarks", emptySet())?.toList().orEmpty()
        if (items.isEmpty()) { Toast.makeText(this, "No bookmarks yet. Tap ☆ on a page to save one.", Toast.LENGTH_LONG).show(); return }
        val builder = android.app.AlertDialog.Builder(this).setTitle("Galaxy bookmarks")
        builder.setItems(items.toTypedArray()) { _, which -> navigate(items[which]) }.setNegativeButton("Close", null).show()
    }
    override fun onBackPressed() { if (::web.isInitialized && web.visibility == View.VISIBLE && web.canGoBack()) web.goBack() else showHome() }
}
